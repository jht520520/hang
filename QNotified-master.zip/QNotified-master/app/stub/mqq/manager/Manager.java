package mqq.manager;

public interface Manager {
    void onDestroy();
}
